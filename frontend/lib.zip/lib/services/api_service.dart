// lib/services/api_service.dart

import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '/models/stock_item.dart'; // Use o nome do seu pacote
import 'package:mime/mime.dart';
import 'package:http_parser/http_parser.dart';
import 'dart:async';

class ApiService {
  // IMPORTANTE: Use o IP da sua máquina visível pela rede onde o dispositivo/emulador está.
  // 'localhost' ou '127.0.0.1' funciona para web ou emulador iOS.
  // Para emulador Android, '10.0.2.2' geralmente aponta para o localhost do host.
  // Se estiver em um dispositivo físico na mesma rede Wi-Fi, use o IP local da máquina host (ex: 192.168.x.x).
  static const String _baseUrl = 'http://192.168.56.1:3000'; // Mantenha o IP que funcionou para você

  // Busca a lista de itens do estoque
  Future<List<StockItem>> fetchStockItems() async {
    final Uri url = Uri.parse('$_baseUrl/stock');
    debugPrint('Buscando itens de estoque em: $url'); // Adiciona log
    try {
      final response = await http.get(url).timeout(const Duration(seconds: 15)); // Aumenta timeout

      if (response.statusCode == 200) {
        List<dynamic> body = jsonDecode(response.body);
        List<StockItem> items = body
            .map((dynamic item) => StockItem.fromJson(item as Map<String, dynamic>))
            .toList();
        debugPrint('Itens de estoque carregados: ${items.length}');
        return items;
      } else {
        debugPrint('Erro HTTP ${response.statusCode} ao buscar estoque: ${response.body}');
        throw Exception('Falha ao carregar estoque (Código: ${response.statusCode})');
      }
    } on SocketException catch (e) {
       debugPrint('Erro de conexão (SocketException) ao buscar estoque: $e. Verifique o endereço ($_baseUrl) e a rede.');
       throw Exception('Não foi possível conectar ao servidor. Verifique sua conexão e o endereço da API.');
    } on FormatException catch (e) {
       debugPrint('Erro de formato (FormatException) ao buscar estoque: $e. Resposta do servidor não é um JSON válido.');
       throw Exception('Resposta inválida do servidor.');
    } catch (e) {
       debugPrint('Erro desconhecido ao buscar estoque: $e');
       throw Exception('Ocorreu um erro inesperado ao buscar dados.');
    }
  }

  // Faz upload de uma imagem para um item específico
  Future<void> uploadImage(int itemId, File imageFile) async {
    final Uri url = Uri.parse('$_baseUrl/stock/$itemId/image');
     debugPrint('Iniciando upload para: $url');
     debugPrint('Arquivo para upload: ${imageFile.path}');
    try {
      var request = http.MultipartRequest('POST', url);

      // --- Determinar o MIME type ---
      String? mimeType = lookupMimeType(imageFile.path);
      MediaType? contentType;

      if (mimeType != null) {
        var typeParts = mimeType.split('/');
        if (typeParts.length == 2) {
          contentType = MediaType(typeParts[0], typeParts[1]);
          debugPrint('MIME Type detectado para upload: $mimeType');
        } else {
           debugPrint('AVISO: Formato MIME type inesperado "$mimeType" para ${imageFile.path}.');
        }
      } else {
         debugPrint('AVISO: Não foi possível determinar o MIME type para ${imageFile.path}. O upload pode falhar ou usar fallback.');
         // Considere adicionar um fallback se necessário, ex:
         contentType = MediaType('application', 'octet-stream');
      }
      // --- Fim da determinação do MIME type ---

      // Adiciona o arquivo à requisição, especificando o Content-Type
      request.files.add(
        await http.MultipartFile.fromPath(
          'productImage', // Nome do campo esperado pelo backend (multer)
          imageFile.path,
          contentType: contentType, // Passa o Content-Type detectado (pode ser null se não detectado)
        ),
      );

      // Envia a requisição
       debugPrint('Enviando requisição de upload...');
      var streamedResponse = await request.send().timeout(const Duration(seconds: 45)); // Timeout maior para upload

       debugPrint('Resposta do servidor recebida (Status: ${streamedResponse.statusCode})');

      // Processa a resposta
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200 || response.statusCode == 201) {
        debugPrint('Upload da imagem bem-sucedido para o item $itemId');
        debugPrint('Resposta do upload: ${response.body}');
        return; // Sucesso
      } else {
        // Log mais detalhado do erro vindo do servidor
        debugPrint('Erro no upload ${response.statusCode}: ${response.body}');
        // Tenta decodificar a resposta JSON se possível para obter a mensagem de erro
        String serverMessage = response.body;
        try {
            var decodedBody = jsonDecode(response.body);
            if (decodedBody is Map && decodedBody.containsKey('message')) {
                serverMessage = decodedBody['message'];
            }
        } catch (_) {
            // Mantém a resposta original se não for JSON ou não tiver 'message'
        }
        throw Exception('Falha ao enviar imagem (Código: ${response.statusCode}) - $serverMessage');
      }
    } on SocketException catch (e) {
       debugPrint('Erro de conexão (SocketException) durante upload: $e. Verifique o endereço ($_baseUrl) e a rede.');
       throw Exception('Não foi possível conectar ao servidor para enviar a imagem.');
    } on TimeoutException catch (e) {
        debugPrint('Timeout durante upload: $e');
        throw Exception('Tempo limite excedido ao enviar a imagem.');
    } catch (e) {
      debugPrint('Erro desconhecido durante upload: $e');
      throw Exception('Ocorreu um erro inesperado ao enviar a imagem: $e');
    }
  }
}
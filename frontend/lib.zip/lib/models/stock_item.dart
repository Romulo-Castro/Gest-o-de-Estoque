// lib/models/stock_item.dart

class StockItem {
  final int id;
  final String name;
  final int quantity;
  final String category;
  final String? imageUrl; // Pode ser nulo se não houver imagem

  StockItem({
    required this.id,
    required this.name,
    required this.quantity,
    required this.category,
    this.imageUrl,
  });

  // Factory constructor para criar um StockItem a partir de um JSON map
  factory StockItem.fromJson(Map<String, dynamic> json) {
    return StockItem(
      id: json['id'] as int? ?? 0, // Adiciona valor padrão caso seja nulo
      name: json['name'] as String? ?? 'Nome Indisponível',
      quantity: json['quantity'] as int? ?? 0,
      category: json['category'] as String? ?? 'Sem Categoria',
      imageUrl: json['imageUrl'] as String?, // Já é nullable
    );
  }

  // Método para facilitar a depuração (opcional)
  @override
  String toString() {
    return 'StockItem(id: $id, name: $name, quantity: $quantity, category: $category, imageUrl: $imageUrl)';
  }
}
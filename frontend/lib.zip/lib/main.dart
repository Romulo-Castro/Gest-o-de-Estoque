// lib/main.dart

import 'package:flutter/material.dart';
import '/screens/stock_screen.dart'; // Ajuste o caminho

void main() {
  // Adicione quaisquer inicializações necessárias aqui (ex: Firebase, etc.)
  runApp(const StockApp());
}

class StockApp extends StatelessWidget {
  const StockApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gestão de Estoques',
      theme: ThemeData(
        primarySwatch: Colors.indigo, // Pode escolher outra cor primária
        visualDensity: VisualDensity.adaptivePlatformDensity, // Adapta a densidade visual
        appBarTheme: const AppBarTheme(
          elevation: 1.0, // Sombra sutil na AppBar
          centerTitle: true, // Centraliza o título
        ),
        useMaterial3: true, // Habilita Material 3 (se seu Flutter suportar)
      ),
      debugShowCheckedModeBanner: false, // Remove o banner de debug
      home: const StockScreen(), // Define a tela inicial
    );
  }
}
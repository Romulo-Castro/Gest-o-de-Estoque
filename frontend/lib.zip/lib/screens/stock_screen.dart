// lib/screens/stock_screen.dart

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '/models/stock_item.dart'; // Ajuste o caminho
import '/services/api_service.dart'; // Ajuste o caminho

class StockScreen extends StatefulWidget {
  const StockScreen({super.key});

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  late Future<List<StockItem>> _stockItemsFuture;
  final ApiService _apiService = ApiService();
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _loadStockItems(); // Carrega os itens ao iniciar a tela
  }

  // Método para (re)carregar os dados da API
  void _loadStockItems() {
    setState(() {
      // Atribui o Future retornado pelo serviço à variável de estado
      // Isso fará o FutureBuilder reconstruir
      _stockItemsFuture = _apiService.fetchStockItems();
    });
  }

  // Método para escolher e fazer upload da imagem
  Future<void> _pickAndUploadImage(int itemId) async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.camera, // Ou ImageSource.gallery para escolher da galeria
        imageQuality: 80, // Opcional: Comprime um pouco a imagem
        maxWidth: 1024, // Opcional: Redimensiona a imagem
      );

      if (image != null && mounted) { // Verifica se a tela ainda está montada
        // Mostra um feedback de carregamento (opcional)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Enviando imagem...'), duration: Duration(seconds: 2)),
        );

        await _apiService.uploadImage(itemId, File(image.path));

        if (mounted) {
           ScaffoldMessenger.of(context).showSnackBar(
             const SnackBar(
               content: Text('Imagem enviada com sucesso!'),
               backgroundColor: Colors.green,
             ),
           );
           _loadStockItems(); // Recarrega a lista para mostrar a nova imagem (se a URL for retornada)
        }

      } else {
         print('Seleção de imagem cancelada ou widget desmontado.');
      }
    } catch (e) {
      print('Erro ao escolher/enviar imagem: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao enviar imagem: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Consulta de Estoque'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Atualizar Lista',
            onPressed: _loadStockItems, // Chama o método para recarregar
          ),
        ],
      ),
      body: FutureBuilder<List<StockItem>>(
        future: _stockItemsFuture,
        builder: (context, snapshot) {
          // Estado de Carregamento
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          // Estado de Erro
          else if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  'Erro ao carregar dados:\n${snapshot.error}\n\nVerifique a conexão e o servidor backend.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.red[700]),
                ),
              ),
            );
          }
          // Estado de Sucesso, mas sem dados ou lista vazia
          else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Nenhum item encontrado no estoque.'));
          }
          // Estado de Sucesso com Dados
          else {
            final stockItems = snapshot.data!;
            return RefreshIndicator( // Permite puxar para atualizar
              onRefresh: () async => _loadStockItems(),
              child: ListView.builder(
                itemCount: stockItems.length,
                itemBuilder: (context, index) {
                  final item = stockItems[index];
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.grey[200], // Fundo padrão
                      // Tenta carregar a imagem da URL se existir
                      backgroundImage: (item.imageUrl != null && item.imageUrl!.isNotEmpty)
                          ? NetworkImage(item.imageUrl!)
                          : null, // Usa NetworkImage se tiver URL
                      // Mostra um ícone padrão se não houver imagem ou se ocorrer erro ao carregar
                      child: (item.imageUrl == null || item.imageUrl!.isEmpty)
                          ? const Icon(Icons.inventory_2_outlined, color: Colors.grey)
                          : null, // Ícone se não houver imagem
                      // Tratamento de erro para NetworkImage (opcional mas bom)
                      onBackgroundImageError: (item.imageUrl != null && item.imageUrl!.isNotEmpty)
                        ? (exception, stackTrace) {
                            print("Erro ao carregar imagem: ${item.imageUrl} -> $exception");
                            // Não precisa fazer setState aqui, o child já é o fallback
                          }
                        : null,
                    ),
                    title: Text(item.name),
                    subtitle: Text('Qtd: ${item.quantity} | Cat: ${item.category}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.camera_alt_outlined),
                      tooltip: 'Adicionar/Alterar Foto',
                      onPressed: () => _pickAndUploadImage(item.id),
                    ),
                    // Adicione onTap se quiser navegar para detalhes do item, etc.
                    // onTap: () { /* Navegar para tela de detalhes */ },
                  );
                },
              ),
            );
          }
        },
      ),
      // Adicione um FloatingActionButton para adicionar novos itens (próximo passo)
      // floatingActionButton: FloatingActionButton(
      //   onPressed: () { /* Navegar para tela de adicionar item */ },
      //   child: const Icon(Icons.add),
      //   tooltip: 'Adicionar Item',
      // ),
    );
  }
}
// src/controllers/stockController.js

const path = require('path');
const fs = require('fs');
const db = require('../data/mockDatabase'); // Importa nosso "banco de dados" simulado
const UPLOAD_DIR = process.env.UPLOAD_FOLDER || 'uploads';
const BASE_URL = process.env.BASE_URL || `http://localhost:${process.env.PORT || 3000}`;

// Função para obter todos os itens do estoque
exports.getAllStockItems = (req, res) => {
    try {
        const items = db.getStock();
        // Mapeia os itens para incluir a URL completa da imagem, se existir
        const itemsWithFullUrls = items.map(item => ({
            ...item,
            imageUrl: item.imageUrl
                ? `${BASE_URL}/${UPLOAD_DIR}/${item.imageUrl}` // Constrói a URL completa
                : null
        }));
        res.status(200).json(itemsWithFullUrls);
    } catch (error) {
        console.error("Erro ao buscar itens de estoque:", error);
        res.status(500).json({ message: "Erro interno ao buscar estoque.", error: error.message });
    }
};

// Função para lidar com o upload da imagem de um item
exports.uploadStockItemImage = (req, res) => {
    const itemId = parseInt(req.params.id, 10); // Converte ID para número

    if (isNaN(itemId)) {
        return res.status(400).json({ message: "ID do item inválido." });
    }

    // Verifica se o multer processou um arquivo
    if (!req.file) {
        return res.status(400).json({ message: 'Nenhuma imagem foi enviada.' });
    }

    // O middleware 'upload' (multer) já salvou o arquivo se chegou até aqui.
    const imageFilename = req.file.filename; // Nome do arquivo salvo pelo multer

    try {
        // Tenta encontrar o item no "banco de dados"
        const itemExists = db.findStockItemById(itemId);

        if (!itemExists) {
            // Se o item não existe, remove o arquivo que foi salvo desnecessariamente
            const filePath = path.join(__dirname, '../../', UPLOAD_DIR, imageFilename);
            fs.unlink(filePath, (err) => {
                if (err) console.error(`Erro ao remover arquivo órfão ${filePath}:`, err);
            });
            return res.status(404).json({ message: `Item com ID ${itemId} não encontrado.` });
        }

        // Atualiza o nome da imagem no item (simulação de DB)
        const updatedItem = db.updateStockItemImage(itemId, imageFilename);

        if (updatedItem) {
            console.log(`Imagem ${imageFilename} associada ao item ID ${itemId}`);
            // Retorna o item atualizado com a URL completa da nova imagem
            res.status(200).json({
                ...updatedItem,
                imageUrl: `${BASE_URL}/${UPLOAD_DIR}/${updatedItem.imageUrl}`
            });
        } else {
             // Caso raro onde o item existia mas a atualização falhou
             return res.status(500).json({ message: "Não foi possível atualizar a imagem do item." });
        }

    } catch (error) {
        console.error(`Erro ao processar upload para item ${itemId}:`, error);
        // Tenta remover o arquivo se houve erro após o upload
        const filePath = path.join(__dirname, '../../', UPLOAD_DIR, imageFilename);
         fs.unlink(filePath, (err) => {
            if (err) console.error(`Erro ao remover arquivo ${filePath} após erro no processamento:`, err);
        });
        res.status(500).json({ message: "Erro interno ao processar o upload da imagem.", error: error.message });
    }
};

// Adicione outras funções de controller aqui (create, update, delete, getById)
// exports.createStockItem = (req, res) => { ... };
// exports.updateStockItem = (req, res) => { ... };
// exports.deleteStockItem = (req, res) => { ... };
// exports.getStockItemById = (req, res) => { ... };
// src/server.js

require('dotenv').config(); // Carrega variáveis do arquivo .env para process.env

const express = require('express');
const cors = require('cors');
const path = require('path');
const multer = require('multer'); // <--- CORREÇÃO JÁ APLICADA (multer está importado)
const stockRoutes = require('./routes/stockRoutes'); // Importa as rotas de estoque

const app = express();
const PORT = process.env.PORT || 3000; // Usa a porta do .env ou 3000 como padrão
const UPLOAD_DIR = process.env.UPLOAD_FOLDER || 'uploads'; // Pega do .env ou usa 'uploads'

// === Middleware ===

// Habilitar CORS para permitir requisições do frontend Flutter (ajuste em produção!)
// Por padrão, permite todas as origens.
app.use(cors());

// Middleware para parsear JSON no corpo das requisições (para futuras rotas POST/PUT)
app.use(express.json());

// Middleware para parsear dados de formulário URL-encoded (menos comum para APIs JSON)
app.use(express.urlencoded({ extended: true }));

// Servir arquivos estáticos da pasta de uploads
// Permite que o frontend acesse as imagens via URL: http://<seu-ip>:<porta>/uploads/<nome-arquivo.jpg>
const uploadsAbsolutePath = path.join(__dirname, '../', UPLOAD_DIR);
console.log(`Configurando rota estática para /${UPLOAD_DIR} em ${uploadsAbsolutePath}`);
app.use(`/${UPLOAD_DIR}`, express.static(uploadsAbsolutePath));


// === Rotas ===

// Rota raiz básica para teste
app.get('/', (req, res) => {
    res.send('API Gestão de Estoques está funcionando!');
});

// Montar as rotas de estoque no prefixo /stock
app.use('/stock', stockRoutes);


// === Tratamento de Erros ===

// Middleware para tratar rotas não encontradas (404)
app.use((req, res, next) => {
    // Se a requisição já teve uma resposta enviada, não faz nada
    if (res.headersSent) {
      return next();
    }
    res.status(404).json({ message: 'Rota não encontrada.' });
});

// Middleware genérico para tratamento de erros (deve ser o último middleware)
// Captura erros que ocorrem em rotas síncronas ou passados via next(error) em assíncronas
app.use((err, req, res, next) => {
    // Se os headers já foram enviados ao cliente, delega para o tratador padrão do Express
    if (res.headersSent) {
      return next(err);
    }

    console.error("Erro não tratado:", err.stack || err); // Loga o erro completo no console do servidor

    // Verifica se é um erro específico do Multer
    if (err instanceof multer.MulterError) {
        return res.status(400).json({ message: `Erro no upload: ${err.message}` });
    }
    // Verifica se é o erro específico do nosso fileFilter
    else if (err.message === 'Tipo de arquivo inválido. Apenas imagens são permitidas.') {
         return res.status(400).json({ message: err.message });
    }

    // Para todos os outros erros, retorna um erro 500 genérico
    res.status(err.status || 500).json({ // Usa o status do erro ou 500 padrão
        message: err.message || 'Ocorreu um erro interno no servidor.',
        // Em ambiente de desenvolvimento, pode ser útil enviar o stack trace (opcional)
        // error: process.env.NODE_ENV === 'development' ? err.stack : undefined
    });
});


// === Iniciar Servidor ===
app.listen(PORT, () => {
    console.log(`\nServidor backend rodando na porta ${PORT}`);
    console.log(`Ambiente: ${process.env.NODE_ENV || 'não definido (usando padrões)'}`);
    console.log(`URL base para imagens: ${process.env.BASE_URL || `http://localhost:${PORT}`}/${UPLOAD_DIR}/`);
    console.log(`Acesse a API em: http://localhost:${PORT}`);
});
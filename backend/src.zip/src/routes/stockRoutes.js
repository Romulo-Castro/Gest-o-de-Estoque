// src/routes/stockRoutes.js

const express = require('express');
const stockController = require('../controllers/stockController');
const upload = require('../middleware/uploadMiddleware'); // Importa o middleware de upload

const router = express.Router();

// Rota para buscar todos os itens
// GET /stock
router.get('/', stockController.getAllStockItems);

// Rota para fazer upload da imagem de um item específico
// O middleware 'upload.single()' processa UM arquivo que vem no campo 'productImage'
// POST /stock/:id/image
router.post(
    '/:id/image',
    upload.single('productImage'), // Nome do campo esperado do frontend!
    stockController.uploadStockItemImage
);

// Adicione outras rotas CRUD aqui
// router.post('/', stockController.createStockItem);       // Criar item
// router.get('/:id', stockController.getStockItemById);     // Buscar item por ID
// router.put('/:id', stockController.updateStockItem);       // Atualizar item
// router.delete('/:id', stockController.deleteStockItem);   // Deletar item

module.exports = router;